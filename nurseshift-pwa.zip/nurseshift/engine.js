/* NurseShift — محرك التوزيع (منطق خالص بدون واجهة) */
(function (root) {
  'use strict';
  const RK = ['nurse', 'assistant'];
  const ROLE_AR = { nurse: 'الممرضين', assistant: 'مساعدي التخدير' };
  // كل الأوقات بالدقائق منذ بداية الشيفت (14:00)
  const C = {
    PERIODS: 9, PLEN: 120, SHIFT_MIN: 1080, START_H: 14,
    CRIT: [
      { k: 'c1', a: 720, b: 840, l: '2–4 ص' },   // 02:00-04:00
      { k: 'c2', a: 840, b: 960, l: '4–6 ص' },   // 04:00-06:00
      { k: 'c3', a: 960, b: 1020, l: '6–7 ص' }   // 06:00-07:00
    ],
    LATE: [480, 720] // 22:00-02:00
  };
  const ov = (a, b, c, d) => Math.max(0, Math.min(b, d) - Math.max(a, c));
  const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

  // ---------- التواريخ ----------
  const pd = s => { const [y, m, d] = s.split('-').map(Number); return Date.UTC(y, m - 1, d); };
  const fd = ms => new Date(ms).toISOString().slice(0, 10);
  const addDays = (s, n) => fd(pd(s) + n * 864e5);
  const diffDays = (a, b) => Math.round((pd(a) - pd(b)) / 864e5);
  const daysIn = ym => { const [y, m] = ym.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).getUTCDate(); };
  const hhmm = m => { m = ((m % 1440) + 1440) % 1440; return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
  const offTime = o => hhmm(C.START_H * 60 + o);
  const timeToOff = t => { const [h, m] = t.split(':').map(Number); return (h * 60 + m - C.START_H * 60 + 1440) % 1440; }; // صالح إذا <= 1080
  const blankPeriods = () => Array.from({ length: C.PERIODS }, () => ({ nurse: null, assistant: null }));

  function createEngine(getDb) {
    const D = () => getDb();
    const staffById = id => D().staff.find(s => s.id === id);
    const attendees = (sh, r) => [...new Set(sh.periods.map(p => p[r]).filter(Boolean))];
    const attAll = sh => [...attendees(sh, 'nurse'), ...attendees(sh, 'assistant')];
    const onLeave = (id, date) => D().leaves.some(l => l.staffId === id && l.from <= date && date <= l.to);

    // ---------- تحليل شيفت واحد (الساعات بالدقيقة بدقة) ----------
    function analyze(sh, light) {
      const seg = {};
      const push = (id, s, e, x) => { if (!id || e <= s) return; (seg[id] = seg[id] || []).push({ s, e, x: !!x }); };
      sh.periods.forEach((p, i) => RK.forEach(r => push(p[r], i * C.PLEN, (i + 1) * C.PLEN, false)));
      (sh.exits || []).forEach(ex => {
        const out = [];
        (seg[ex.staffId] || []).forEach(g => {
          if (ex.to <= g.s || ex.from >= g.e) { out.push(g); return; }
          if (g.s < ex.from) out.push({ s: g.s, e: ex.from, x: g.x });
          if (g.e > ex.to) out.push({ s: ex.to, e: g.e, x: g.x });
        });
        seg[ex.staffId] = out;
        if (ex.subId) {
          const cf = Math.max(ex.from, ex.covFrom == null ? ex.from : ex.covFrom);
          const ct = Math.min(ex.to, ex.covTo == null ? ex.to : ex.covTo);
          push(ex.subId, cf, ct, true);
        }
      });
      const cov = { nurse: new Uint8Array(C.SHIFT_MIN), assistant: new Uint8Array(C.SHIFT_MIN) };
      const per = {}, conflicts = [];
      for (const id in seg) {
        const st = staffById(id), role = st ? st.role : null;
        const arr = seg[id].sort((a, b) => a.s - b.s);
        const m = { min: 0, extra: 0, c1: 0, c2: 0, c3: 0, late: 0, shifts: 0 };
        arr.forEach(g => {
          m.min += g.e - g.s;
          if (g.x) m.extra += g.e - g.s;
          C.CRIT.forEach(c => { m[c.k] += ov(g.s, g.e, c.a, c.b); });
          m.late += ov(g.s, g.e, C.LATE[0], C.LATE[1]);
          if (role) for (let t = g.s; t < g.e; t++) cov[role][t]++;
        });
        if (m.min > 0) m.shifts = 1;
        per[id] = m;
        let cur = null; const blocks = [];
        arr.forEach(g => { if (cur && g.s <= cur.e) cur.e = Math.max(cur.e, g.e); else { cur = { s: g.s, e: g.e }; blocks.push(cur); } });
        blocks.forEach(b => { if (b.e - b.s > C.PLEN) conflicts.push({ id, s: b.s, e: b.e }); });
      }
      const unc = [];
      RK.forEach(r => {
        let s = null;
        for (let t = 0; t <= C.SHIFT_MIN; t++) {
          const z = t < C.SHIFT_MIN && cov[r][t] === 0;
          if (z && s === null) s = t;
          if (!z && s !== null) { unc.push({ role: r, s, e: t }); s = null; }
        }
      });
      const ps = [];
      for (let i = 0; i < C.PERIODS; i++) {
        let none = false, part = false;
        RK.forEach(r => {
          let c = 0;
          for (let t = i * C.PLEN; t < (i + 1) * C.PLEN; t++) if (cov[r][t] > 0) c++;
          if (c === 0) none = true; else if (c < C.PLEN) part = true;
        });
        ps.push(none ? 'none' : part ? 'partial' : 'ok');
      }
      const empty = !sh.periods.some(p => p.nurse || p.assistant);
      const res = { seg, per, cov, unc, ps, conflicts, restV: [], leaveV: [], empty };
      if (!light) {
        const rest = D().settings.restDays;
        attAll(sh).forEach(id => {
          if (onLeave(id, sh.date)) res.leaveV.push({ id });
          D().shifts.forEach(o => {
            if (o.id === sh.id || !attAll(o).includes(id)) return;
            const k = Math.abs(diffDays(o.date, sh.date));
            if (k <= rest) res.restV.push({ id, other: o.date, k });
          });
        });
      }
      return res;
    }

    // ---------- مقاييس تراكمية ----------
    const zero = () => ({ min: 0, extra: 0, c1: 0, c2: 0, c3: 0, late: 0, shifts: 0 });
    function metrics(excludeId, month) {
      const m = {};
      D().staff.forEach(s => { m[s.id] = zero(); });
      D().shifts.forEach(sh => {
        if (sh.id === excludeId) return;
        if (month && sh.month !== month) return;
        const a = analyze(sh, true);
        for (const id in a.per) { const t = m[id] || (m[id] = zero()); for (const k in a.per[id]) t[k] += a.per[id][k]; }
      });
      return m;
    }
    // العبء: كلما زاد = حمل أكبر. الراحة الأطول تُنقص العبء (أولوية للعمل)
    function burden(mt, restDaysSince) {
      const w = D().settings.w;
      return mt.min / 60 * w.hours + mt.extra / 60 * w.extra +
        (mt.c1 + mt.c2 + mt.c3) / 60 * w.crit + mt.late / C.PLEN * w.late +
        mt.shifts * w.shifts - Math.min(restDaysSince, 14) * w.rest;
    }

    // ---------- توزيع الفترات داخل الشيفت لدور واحد ----------
    function assignRole(sh, role, ids, base, prevCrit) {
      const n = ids.length, P = C.PERIODS, w = D().settings.w;
      if (n === 0) { sh.periods.forEach(p => { p[role] = null; }); return; }
      const pl = [], critH = [];
      for (let i = 0; i < P; i++) {
        const a = i * C.PLEN, b = a + C.PLEN;
        critH[i] = ov(a, b, 720, 1020) / 60;
        pl[i] = 2 * w.hours + critH[i] * w.crit + ov(a, b, C.LATE[0], C.LATE[1]) / C.PLEN * w.late;
      }
      const load = ids.map((id, k) => pl.map((v, i) => v + (prevCrit[k] ? critH[i] * w.crit * 1.5 : 0)));
      let best = Infinity, bestSeq = null;
      const seq = new Array(P), add = new Array(n).fill(0);
      (function dfs(i, last) {
        if (i === P) {
          let c = 0; for (let k = 0; k < n; k++) c += (base[k] + add[k]) ** 2;
          if (c < best - 1e-9) { best = c; bestSeq = seq.slice(); }
          return;
        }
        for (let k = 0; k < n; k++) {
          if (n > 1 && k === last) continue; // منع فترتين متتاليتين
          seq[i] = k; add[k] += load[k][i]; dfs(i + 1, k); add[k] -= load[k][i];
        }
      })(0, -1);
      bestSeq.forEach((k, i) => { sh.periods[i][role] = ids[k]; });
    }

    // ---------- توليد/إعادة توزيع شيفت ----------
    function generateShift(sh, opts) {
      opts = opts || {};
      const db = D(), st = db.settings, rest = st.restDays;
      const mt = metrics(sh.id, st.scope === 'month' ? sh.month : null);
      const dates = {};
      db.shifts.forEach(o => { if (o.id === sh.id) return; attAll(o).forEach(id => (dates[id] = dates[id] || []).push(o.date)); });
      const gap = id => { let g = Infinity; (dates[id] || []).forEach(d => { g = Math.min(g, Math.abs(diffDays(d, sh.date))); }); return g; };
      const since = id => { let g = 14; (dates[id] || []).forEach(d => { const k = diffDays(sh.date, d); if (k > 0) g = Math.min(g, k); }); return g; };
      const sc = id => burden(mt[id] || zero(), since(id));
      const prevCritOf = id => {
        const prior = db.shifts.filter(o => o.id !== sh.id && o.date < sh.date && attAll(o).includes(id)).sort((a, b) => b.date.localeCompare(a.date))[0];
        if (!prior) return false;
        const p = analyze(prior, true).per[id]; return !!p && (p.c1 + p.c2 + p.c3) > 0;
      };
      const warn = [], chosen = {};
      RK.forEach(r => {
        const need = Math.max(1, Math.min(4, st.perShift[r] | 0));
        const pool = db.staff.filter(s => s.active !== false && s.role === r && !onLeave(s.id, sh.date));
        const ok = pool.filter(s => gap(s.id) > rest);
        let ch = [];
        (opts.keep || []).forEach(id => { if (ch.length < need && ok.some(s => s.id === id) && !ch.includes(id)) ch.push(id); });
        ok.filter(s => !ch.includes(s.id)).sort((a, b) => sc(a.id) - sc(b.id)).forEach(s => { if (ch.length < need) ch.push(s.id); });
        if (ch.length < need) {
          pool.filter(s => !ch.includes(s.id)).sort((a, b) => gap(b.id) - gap(a.id) || sc(a.id) - sc(b.id)).forEach(s => {
            if (ch.length >= need) return;
            ch.push(s.id);
            warn.push(`تم استثناء قاعدة الراحة للموظف ${s.name} (فاصل ${gap(s.id)} يوم فقط) بسبب نقص الكادر`);
          });
        }
        if (ch.length < need) warn.push(`المتاح من ${ROLE_AR[r]} ${ch.length} فقط من أصل ${need} مطلوب`);
        if (ch.length === 1) warn.push(`${ROLE_AR[r]}: شخص واحد فقط — لا يمكن تجنب العمل المتواصل 4 ساعات (استثناء إجباري)`);
        if (ch.length === 0) warn.push(`لا يوجد أي من ${ROLE_AR[r]} متاح — فترات بلا تغطية (الحد الآمن غير متحقق)`);
        chosen[r] = ch;
      });
      sh.periods = blankPeriods();
      RK.forEach(r => {
        const ids = chosen[r];
        assignRole(sh, r, ids, ids.map(id => sc(id)), ids.map(prevCritOf));
      });
      sh.warn = warn;
      // مسؤول التسليم والاستلام: الأقل تكراراً ثم الأقل عبئاً
      const cands = attAll(sh);
      const hc = {};
      db.shifts.forEach(o => { if (o.id !== sh.id && o.handover && o.handover.personId) hc[o.handover.personId] = (hc[o.handover.personId] || 0) + 1; });
      const keepH = sh.handover && cands.includes(sh.handover.personId);
      if (!sh.handover) sh.handover = { personId: null, at: '', notes: '', pending: '', incoming: '', confirmed: false, sign: null };
      if (!keepH) sh.handover.personId = cands.sort((a, b) => (hc[a] || 0) - (hc[b] || 0) || sc(a) - sc(b))[0] || null;
      return sh;
    }

    function renumber(ym) {
      D().shifts.filter(s => s.month === ym).sort((a, b) => a.date.localeCompare(b.date)).forEach((s, i) => { s.no = i + 1; });
    }

    function generateMonth(ym) {
      const db = D(), n = Math.max(1, db.settings.shiftsPerMonth | 0), days = daysIn(ym);
      db.shifts = db.shifts.filter(s => s.month !== ym);
      let prev = 0; const made = [];
      for (let i = 0; i < n; i++) {
        let day = 1 + Math.round(i * (days - 1) / n);
        if (day <= prev) day = prev + 1;
        if (day > days) day = days;
        prev = day;
        made.push({ id: uid(), month: ym, date: `${ym}-${String(day).padStart(2, '0')}`, no: i + 1, periods: blankPeriods(), exits: [], handover: null, warn: [] });
      }
      made.forEach(s => db.shifts.push(s));
      made.forEach(s => generateShift(s));
      renumber(ym);
      return made;
    }

    // ---------- اقتراح بديل للخروج الطارئ ----------
    function suggestSubs(sh, ex) {
      const db = D(), st = db.settings, rest = st.restDays;
      const exiting = staffById(ex.staffId); if (!exiting) return [];
      const a = analyze(sh, true);
      const mt = metrics(null, st.scope === 'month' ? sh.month : null);
      const inShift = attAll(sh);
      return db.staff.filter(s => s.active !== false && s.role === exiting.role && s.id !== ex.staffId && !onLeave(s.id, sh.date)).map(s => {
        const mine = a.seg[s.id] || [];
        const overlap = mine.some(g => ov(g.s, g.e, ex.from, ex.to) > 0);
        let cur = null, run = false;
        mine.concat([{ s: ex.from, e: ex.to }]).sort((x, y) => x.s - y.s).forEach(g => {
          if (cur && g.s <= cur.e) cur.e = Math.max(cur.e, g.e); else cur = { s: g.s, e: g.e };
          if (cur.e - cur.s > C.PLEN) run = true;
        });
        let restBad = false, since = 14;
        if (!inShift.includes(s.id)) {
          db.shifts.forEach(o => {
            if (o.id === sh.id || !attAll(o).includes(s.id)) return;
            const k = Math.abs(diffDays(o.date, sh.date));
            if (k <= rest) restBad = true;
            const k2 = diffDays(sh.date, o.date); if (k2 > 0) since = Math.min(since, k2);
          });
        }
        const reasons = [];
        if (overlap) reasons.push('يعمل في نفس الوقت');
        if (run) reasons.push('يتجاوز ساعتين متواصلتين');
        if (restBad) reasons.push('ضمن أيام الراحة');
        return { id: s.id, name: s.name, score: burden(mt[s.id] || zero(), since), ok: reasons.length === 0, reasons, onShift: inShift.includes(s.id) };
      }).sort((x, y) => (y.ok - x.ok) || (x.score - y.score));
    }

    // ---------- جدول ملخص الموظفين ----------
    function rows(month) {
      const db = D(), mt = metrics(null, month), hc = {};
      db.shifts.forEach(sh => { if (month && sh.month !== month) return; const p = sh.handover && sh.handover.personId; if (p) hc[p] = (hc[p] || 0) + 1; });
      return db.staff.filter(s => s.active !== false || (mt[s.id] && mt[s.id].min > 0)).map(s => {
        const m = mt[s.id] || zero();
        const ds = db.shifts.filter(sh => (!month || sh.month === month) && attAll(sh).includes(s.id)).map(sh => sh.date).sort();
        let minRest = null;
        for (let i = 1; i < ds.length; i++) { const g = diffDays(ds[i], ds[i - 1]) - 1; if (minRest === null || g < minRest) minRest = g; }
        return Object.assign({ id: s.id, name: s.name, role: s.role, crit: m.c1 + m.c2 + m.c3, burden: burden(m, 0), hand: hc[s.id] || 0, minRest }, m);
      });
    }

    return { analyze, metrics, burden, generateShift, generateMonth, suggestSubs, rows, renumber, attendees, attAll, onLeave, staffById };
  }

  const api = { createEngine, C, RK, ROLE_AR, utils: { uid, pd, fd, addDays, diffDays, daysIn, hhmm, offTime, timeToOff, blankPeriods, ov } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.NSEngine = api;
})(typeof self !== 'undefined' ? self : globalThis);
