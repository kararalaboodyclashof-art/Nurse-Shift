/* NurseShift — الواجهة */
(function () {
  'use strict';
  const E = NSEngine, C = E.C, RK = E.RK, U = E.utils;
  const KEY = 'nurseshift_db_v1', BAK = 'nurseshift_db_bak';
  const ROLE = { nurse: 'ممرض/ة', assistant: 'مساعد/ة تخدير' };
  const ROLE_P = { nurse: 'الممرضون', assistant: 'مساعدو التخدير' };
  const STAT = { ok: 'مغطّاة', partial: 'تغطية جزئية', none: 'غير مغطّاة' };
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ---------- قاعدة البيانات (حفظ تلقائي محلي) ----------
  const defaults = () => ({
    v: 1, staff: [], shifts: [], leaves: [], audit: [],
    settings: { shiftsPerMonth: 9, restDays: 3, perShift: { nurse: 2, assistant: 2 }, scope: 'all', w: { hours: 1, extra: 1.5, crit: 3, late: 2, shifts: 2, rest: 0.5 }, pin: null }
  });
  function normalize(d) {
    const b = defaults(), s = d.settings || {};
    return {
      v: 1, staff: d.staff || [], shifts: d.shifts || [], leaves: d.leaves || [], audit: d.audit || [],
      settings: Object.assign({}, b.settings, s, { w: Object.assign({}, b.settings.w, s.w), perShift: Object.assign({}, b.settings.perShift, s.perShift) })
    };
  }
  let db = (function () { try { const r = localStorage.getItem(KEY); if (r) return normalize(JSON.parse(r)); } catch (e) { } return defaults(); })();
  const eng = E.createEngine(() => db);
  function save() {
    try {
      const prev = localStorage.getItem(KEY); if (prev) localStorage.setItem(BAK, prev);
      localStorage.setItem(KEY, JSON.stringify(db));
    } catch (e) { toast('تعذر الحفظ: ' + e.message, 'bad'); }
  }
  function log(a, d) { db.audit.unshift({ t: Date.now(), a, d: d || '' }); if (db.audit.length > 600) db.audit.length = 600; }
  const nm = id => { const s = eng.staffById(id); return s ? s.name + (s.active === false ? ' (مؤرشف)' : '') : '—'; };
  const uid = U.uid;

  // ---------- أدوات ----------
  const ui = { tab: 'dash', month: curMonth(), shiftId: null, rep: 'month', repShift: null, exShift: null, unlocked: false, sugg: [] };
  function curMonth() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }
  function todayStr() { const d = new Date(); return curMonth() + '-' + String(d.getDate()).padStart(2, '0'); }
  function addMonth(ym, n) { const [y, m] = ym.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }
  function fmtDate(s) { try { return new Date(U.pd(s)).toLocaleDateString('ar-EG-u-nu-latn', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }); } catch (e) { return s; } }
  function fmtMonth(ym) { try { const [y, m] = ym.split('-').map(Number); return new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString('ar-EG-u-nu-latn', { month: 'long', year: 'numeric', timeZone: 'UTC' }); } catch (e) { return ym; } }
  const h1 = m => (m / 60).toFixed(m % 60 ? 1 : 0);
  const pLabel = i => U.offTime(i * 120) + '–' + U.offTime((i + 1) * 120);
  const sorted = () => db.shifts.slice().sort((a, b) => a.date.localeCompare(b.date));
  const byId = id => db.shifts.find(s => s.id === id);
  const startMs = sh => { const [y, m, d] = sh.date.split('-').map(Number); return new Date(y, m - 1, d, 14, 0).getTime(); };
  const shLabel = sh => '#' + sh.no + ' — ' + fmtDate(sh.date);
  const opt = (v, t, sel) => `<option value="${esc(v)}"${String(sel) === String(v) ? ' selected' : ''}>${esc(t)}</option>`;
  const short = id => { const s = eng.staffById(id); return s ? s.name.split(' ')[0] : '—'; };
  function curShift() {
    const now = Date.now(), list = sorted();
    for (const sh of list) { const s = startMs(sh); if (now >= s && now < s + 18 * 3600e3) return { sh, live: true }; }
    const up = list.find(sh => startMs(sh) > now);
    return { sh: up || list[list.length - 1] || null, live: false };
  }
  const cyrb = str => { let h1 = 0xdeadbeef, h2 = 0x41c6ce57; for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); } h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909); h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909); return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).toUpperCase(); };
  function toast(m, k) { const t = $('#toast'); t.textContent = m; t.className = 'show ' + (k || ''); clearTimeout(toast.t); toast.t = setTimeout(() => { t.className = ''; }, 3800); }
  function dl(name, mime, content) { const b = new Blob([content], { type: mime }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); }
  function modal(title, body) { $('#modal').innerHTML = `<div class="mback" data-act="close"></div><div class="mbox" role="dialog"><div class="mhead"><b>${esc(title)}</b><button class="x" data-act="close" aria-label="إغلاق">✕</button></div>${body}</div>`; $('#modal').className = 'open'; }
  function closeModal() { $('#modal').className = ''; $('#modal').innerHTML = ''; }

  // ---------- التنبيهات ----------
  function alertsFor(sh, a) {
    const L = [];
    (sh.warn || []).forEach(m => L.push(['warn', m]));
    if (a.empty) L.push(['bad', 'لا يوجد طاقم موزّع على هذا الشيفت']);
    else a.unc.forEach(u => L.push(['bad', `تحذير للمشرف: ${ROLE[u.role]} غير مغطّى ${U.offTime(u.s)}–${U.offTime(u.e)} — الحد الآمن للتغطية غير متحقق`]));
    a.conflicts.forEach(c => L.push(['bad', `تعارض: ${nm(c.id)} يعمل ${h1(c.e - c.s)} ساعات متواصلة (${U.offTime(c.s)}–${U.offTime(c.e)}) — مخالفة قاعدة منع 4 ساعات`]));
    a.restV.forEach(r => L.push(['warn', `${nm(r.id)}: فاصل ${r.k} يوم فقط عن شيفت ${r.other} (المطلوب أكثر من ${db.settings.restDays} أيام راحة)`]));
    a.leaveV.forEach(r => L.push(['bad', `${nm(r.id)} في إجازة بتاريخ هذا الشيفت — يلزم إعادة التوزيع`]));
    return L;
  }
  const alertHtml = L => L.length ? L.map(([k, m]) => `<div class="al ${k}">${k === 'bad' ? '⛔' : '⚠️'} ${esc(m)}</div>`).join('') : '<div class="al good">✅ لا توجد تنبيهات</div>';

  // ---------- العروض ----------
  const TABS = [['dash', '🏠', 'اللوحة'], ['sched', '📅', 'الجدول'], ['staff', '👥', 'الطاقم'], ['leave', '🌴', 'الإجازات'], ['exit', '🚪', 'خروج طارئ'], ['hand', '📝', 'التسليم'], ['rep', '📊', 'التقارير'], ['set', '⚙️', 'الإعدادات']];
  function render() {
    const y = window.scrollY;
    const app = $('#app');
    if (db.settings.pin && !ui.unlocked) { app.innerHTML = lockView(); return; }
    app.innerHTML = `<header class="top no-print"><div class="brand">🩺 NurseShift</div><div class="hbtns">${deferred ? '<button class="btn sm" data-act="install">⬇ تثبيت</button>' : ''}${db.settings.pin ? '<button class="btn sm ghost" data-act="lock">🔒 قفل</button>' : ''}</div></header>
    <nav class="tabs no-print">${TABS.map(t => `<button class="${ui.tab === t[0] ? 'on' : ''}" data-act="tab" data-tab="${t[0]}"><span>${t[1]}</span>${t[2]}</button>`).join('')}</nav>
    <main id="view">${VIEWS[ui.tab]()}</main>`;
    window.scrollTo(0, y);
  }
  function lockView() {
    return `<div class="lock"><div class="card"><h2>🔒 NurseShift</h2><p>أدخل الرمز السري للدخول</p><form data-form="unlock"><input name="pin" type="password" inputmode="numeric" autocomplete="off" required autofocus placeholder="الرمز السري"><button class="btn pri block">دخول</button></form></div></div>`;
  }
  const empty = (msg, btn) => `<div class="card center"><p>${msg}</p>${btn || ''}</div>`;

  function vDash() {
    if (!db.staff.length) return empty('ابدأ بإضافة أسماء الطاقم (ممرضون ومساعدو تخدير). قاعدة البيانات فارغة.', '<button class="btn pri" data-act="tab" data-tab="staff">إضافة الطاقم</button>');
    const cs = ui.shiftId && byId(ui.shiftId) ? { sh: byId(ui.shiftId), live: false } : curShift();
    if (!cs.sh) return empty('لا يوجد جدول بعد.', '<button class="btn pri" data-act="genMonth">توليد جدول الشهر</button>') + '';
    const sh = cs.sh, a = eng.analyze(sh), live = cs.live && !ui.shiftId;
    const livePi = live ? Math.floor((Date.now() - startMs(sh)) / 7200e3) : -1;
    const end = U.addDays(sh.date, 1);
    const leaves = db.leaves.filter(l => l.from <= sh.date && sh.date <= l.to);
    const exs = sh.exits || [];
    const cells = sh.periods.map((p, i) => {
      const crit = U.ov(i * 120, i * 120 + 120, 720, 1020) > 0;
      const exHere = exs.filter(x => U.ov(x.from, x.to, i * 120, i * 120 + 120) > 0);
      return `<div class="per ${a.ps[i]}${i === livePi ? ' live' : ''}${crit ? ' crit' : ''}">
        <div class="ph"><b>${i + 1}</b><span>${pLabel(i)}</span>${crit ? '<i class="tag">حرجة</i>' : ''}${i === livePi ? '<i class="tag live">الآن</i>' : ''}</div>
        ${RK.map(r => `<button class="chip r-${r}" data-act="ovr" data-id="${sh.id}" data-i="${i}" data-r="${r}"><small>${r === 'nurse' ? 'ممرض' : 'تخدير'}</small> ${p[r] ? esc(nm(p[r])) : '<em>— فارغ —</em>'}</button>`).join('')}
        ${exHere.map(x => `<div class="mini">🚪 ${esc(short(x.staffId))} ← ${x.subId ? esc(short(x.subId)) : '<b>بلا بديل</b>'}</div>`).join('')}
        <div class="st">${STAT[a.ps[i]]}</div></div>`;
    }).join('');
    const hp = sh.handover && sh.handover.personId;
    const bal = eng.rows(null);
    const mx = Math.max(1, ...bal.map(r => r.burden));
    const bar = r => `<tr><td>${esc(r.name)}<small> ${ROLE[r.role]}</small></td><td>${h1(r.min)}</td><td>${h1(r.extra)}</td><td>${h1(r.crit)}</td><td>${(r.late / 120).toFixed(1)}</td><td>${r.shifts}</td><td class="barc"><div class="bar"><i style="width:${Math.max(2, r.burden / mx * 100)}%"></i></div></td></tr>`;
    return `<div class="card">
      <div class="row between wrap"><div><h2>${live ? '🟢 الشيفت الحالي' : 'الشيفت'} #${sh.no}</h2><div class="muted">${fmtDate(sh.date)} 14:00 ← ${fmtDate(end)} 08:00 (18 ساعة)</div></div>
      <select data-chg="dashShift">${sorted().map(s => opt(s.id, shLabel(s), sh.id)).join('')}</select></div>
      <div class="grid2 gap"><div><h4>الحاضرون</h4>${RK.map(r => `<div class="chips"><b class="lbl">${ROLE_P[r]}:</b> ${eng.attendees(sh, r).map(id => `<span class="pill">${esc(nm(id))} <small>${h1((a.per[id] || { min: 0 }).min)}س</small></span>`).join('') || '<em>لا أحد</em>'}</div>`).join('')}
      <h4>الإجازات في هذا اليوم</h4><div class="chips">${leaves.map(l => `<span class="pill gray">${esc(nm(l.staffId))}${l.note ? ' — ' + esc(l.note) : ''}</span>`).join('') || '<em>لا يوجد</em>'}</div>
      <h4>مسؤول التسليم والاستلام</h4><div class="chips">${hp ? `<span class="pill pri">📝 ${esc(nm(hp))}</span>` : '<em>غير محدد</em>'}</div></div>
      <div><h4>التنبيهات</h4>${alertHtml(alertsFor(sh, a))}</div></div></div>
    <div class="card"><div class="row between wrap"><h3>الفترات التسع (كل فترة ساعتان)</h3><div class="legend"><i class="ok"></i>مغطّاة <i class="partial"></i>جزئية <i class="none"></i>غير مغطّاة <i class="crit"></i>حرجة 2–7 ص</div></div><div class="pgrid">${cells}</div>
      <div class="row gap wrap mt no-print"><button class="btn" data-act="replanKeep" data-id="${sh.id}">🔄 إعادة توزيع (إبقاء الحاضرين)</button><button class="btn" data-act="replanFresh" data-id="${sh.id}">🎲 توزيع جديد كلياً</button><button class="btn" data-act="tab" data-tab="exit" data-id="${sh.id}">🚪 تسجيل خروج طارئ</button></div></div>
    ${exs.length ? `<div class="card"><h3>الخروج الطارئ في هذا الشيفت</h3>${exitTable(sh, false)}</div>` : ''}
    <div class="card"><h3>موازنة ساعات العمل (تراكمي)</h3><div class="tscroll"><table><thead><tr><th>الاسم</th><th>ساعات</th><th>تغطية إضافية</th><th>حرجة</th><th>فترات ليلية</th><th>شيفتات</th><th>العبء</th></tr></thead><tbody>${bal.map(bar).join('')}</tbody></table></div></div>`;
  }

  function vSched() {
    const ms = sorted().filter(s => s.month === ui.month);
    const nav = `<div class="row between wrap"><div class="row gap"><button class="btn sm" data-act="mprev">◀</button><b class="mt-title">${fmtMonth(ui.month)}</b><button class="btn sm" data-act="mnext">▶</button></div><button class="btn pri" data-act="genMonth">⚡ توليد جدول الشهر (${db.settings.shiftsPerMonth} شيفتات)</button></div>`;
    if (!ms.length) return `<div class="card">${nav}<p class="muted mt">لا يوجد جدول لهذا الشهر${db.staff.length ? '' : ' — أضف الطاقم أولاً'}.</p></div>`;
    const rowsH = ms.map(sh => {
      const a = eng.analyze(sh), L = alertsFor(sh, a), bad = L.filter(x => x[0] === 'bad').length;
      return `<tr><td>${sh.no}</td><td>${fmtDate(sh.date)}</td><td>${eng.attendees(sh, 'nurse').map(id => esc(nm(id))).join('، ') || '—'}</td><td>${eng.attendees(sh, 'assistant').map(id => esc(nm(id))).join('، ') || '—'}</td><td>${sh.handover && sh.handover.personId ? esc(nm(sh.handover.personId)) : '—'}</td><td>${bad ? `<span class="pill red">${bad} ⛔</span>` : L.length ? `<span class="pill amber">${L.length} ⚠️</span>` : '<span class="pill green">✓</span>'}</td>
      <td class="acts no-print"><button class="btn sm" data-act="openShift" data-id="${sh.id}">فتح</button><button class="btn sm" data-act="editDate" data-id="${sh.id}">📅</button><button class="btn sm danger" data-act="delShift" data-id="${sh.id}">🗑</button></td></tr>`;
    }).join('');
    const mat = `<table class="mat"><thead><tr><th>الفترة</th>${ms.map(s => `<th>${s.no}<small>${s.date.slice(8)}</small></th>`).join('')}</tr></thead><tbody>${Array.from({ length: 9 }, (_, i) => `<tr><th>${pLabel(i)}</th>${ms.map(s => `<td><span class="n">${esc(short(s.periods[i].nurse))}</span><span class="a">${esc(short(s.periods[i].assistant))}</span></td>`).join('')}</tr>`).join('')}</tbody></table>`;
    return `<div class="card">${nav}<div class="tscroll mt"><table><thead><tr><th>#</th><th>التاريخ</th><th>الممرضون</th><th>مساعدو التخدير</th><th>التسليم</th><th>الحالة</th><th class="no-print"></th></tr></thead><tbody>${rowsH}</tbody></table></div></div>
    <div class="card"><h3>مصفوفة الشهر <small class="muted">(<span class="n">أزرق</span> ممرض · <span class="a">أخضر</span> تخدير)</small></h3><div class="tscroll">${mat}</div></div>`;
  }

  function vStaff() {
    const used = id => db.shifts.some(s => eng.attAll(s).includes(id) || (s.exits || []).some(x => x.staffId === id || x.subId === id));
    return `<div class="grid2 gap">${RK.map(r => {
      const list = db.staff.filter(s => s.role === r);
      return `<div class="card"><div class="row between"><h3>${ROLE_P[r]} <span class="pill">${list.filter(s => s.active !== false).length}</span></h3></div>
      <form data-form="addStaff" class="row gap"><input type="hidden" name="role" value="${r}"><input name="name" required maxlength="40" placeholder="اسم جديد"><button class="btn pri">＋ إضافة</button></form>
      <ul class="list">${list.map(s => `<li class="${s.active === false ? 'off' : ''}"><span>${esc(s.name)}${s.active === false ? ' <small>(مؤرشف)</small>' : ''}</span><span class="acts"><button class="btn sm" data-act="renameStaff" data-id="${s.id}">✏️</button>${s.active === false ? `<button class="btn sm" data-act="restoreStaff" data-id="${s.id}">↩</button>` : ''}<button class="btn sm danger" data-act="delStaff" data-id="${s.id}">${used(s.id) ? 'أرشفة' : '🗑'}</button></span></li>`).join('') || '<li class="muted">لا توجد أسماء بعد</li>'}</ul></div>`;
    }).join('')}</div><div class="card muted">💡 الحد الأدنى الموصى به: شخصان على الأقل من كل تخصص لكل شيفت لتفادي العمل المتواصل 4 ساعات. الأسماء المرتبطة بشيفتات سابقة تُؤرشف بدل الحذف للحفاظ على السجلات.</div>`;
  }

  function vLeave() {
    const act = db.staff.filter(s => s.active !== false);
    return `<div class="card"><h3>تسجيل إجازة / غياب</h3>${act.length ? `<form data-form="addLeave" class="fgrid"><label>الموظف<select name="staffId" required>${act.map(s => opt(s.id, s.name + ' — ' + ROLE[s.role])).join('')}</select></label><label>من<input type="date" name="from" value="${todayStr()}" required></label><label>إلى<input type="date" name="to" value="${todayStr()}" required></label><label>ملاحظة<input name="note" maxlength="60"></label><button class="btn pri">حفظ وإعادة التوزيع تلقائياً</button></form>` : '<p class="muted">أضف الطاقم أولاً.</p>'}</div>
    <div class="card"><h3>الإجازات المسجلة</h3><div class="tscroll"><table><thead><tr><th>الموظف</th><th>من</th><th>إلى</th><th>ملاحظة</th><th></th></tr></thead><tbody>${db.leaves.slice().sort((a, b) => b.from.localeCompare(a.from)).map(l => `<tr><td>${esc(nm(l.staffId))}</td><td>${l.from}</td><td>${l.to}</td><td>${esc(l.note)}</td><td><button class="btn sm danger" data-act="delLeave" data-id="${l.id}">🗑</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted">لا توجد إجازات</td></tr>'}</tbody></table></div><p class="muted">عند إضافة إجازة يُعاد توزيع الشيفتات القادمة المتأثرة تلقائياً مع إبقاء بقية الحاضرين، وتتحدّث مقاييس العدالة.</p></div>`;
  }

  function exitTable(sh, del) {
    const a = eng.analyze(sh);
    return `<div class="tscroll"><table><thead><tr><th>الموظف</th><th>الخروج</th><th>العودة</th><th>السبب</th><th>البديل</th><th>مدة التغطية</th>${del ? '<th></th>' : ''}</tr></thead><tbody>${(sh.exits || []).map(x => {
      const cov = x.subId ? Math.max(0, Math.min(x.to, x.covTo == null ? x.to : x.covTo) - Math.max(x.from, x.covFrom == null ? x.from : x.covFrom)) : 0;
      const gap = (x.to - x.from) - cov;
      return `<tr><td>${esc(nm(x.staffId))}</td><td>${U.offTime(x.from)}</td><td>${U.offTime(x.to)}</td><td>${esc(x.reason)}</td><td>${x.subId ? esc(nm(x.subId)) : '<span class="pill red">بلا بديل</span>'}</td><td>${cov} د${gap > 0 ? ` <span class="pill amber">غير مغطّى ${gap} د</span>` : ''}</td>${del ? `<td><button class="btn sm danger" data-act="delExit" data-id="${sh.id}" data-x="${x.id}">🗑</button></td>` : ''}</tr>`;
    }).join('')}</tbody></table></div>${a.unc.length ? `<div class="al bad">⛔ فترات غير مغطّاة: ${a.unc.map(u => ROLE[u.role] + ' ' + U.offTime(u.s) + '–' + U.offTime(u.e)).join(' ، ')}</div>` : ''}`;
  }

  function vExit() {
    const list = sorted();
    if (!list.length) return empty('لا توجد شيفتات بعد. ولّد جدولاً أولاً.', '<button class="btn pri" data-act="tab" data-tab="sched">الجدول</button>');
    const sh = byId(ui.exShift) || (curShift().sh);
    ui.exShift = sh.id;
    const atts = eng.attAll(sh), sugg = ui.sugg || [];
    const subs = db.staff.filter(s => s.active !== false);
    return `<div class="card"><div class="row between wrap"><h3>🚪 تسجيل خروج طارئ (1–2 ساعة)</h3><select data-chg="exShift">${list.map(s => opt(s.id, shLabel(s), sh.id)).join('')}</select></div>
    <form data-form="addExit" class="fgrid"><input type="hidden" name="shiftId" value="${sh.id}">
      <label>الموظف الخارج<select name="staffId" required>${atts.map(id => opt(id, nm(id) + ' — ' + ROLE[eng.staffById(id).role])).join('')}</select></label>
      <label>وقت الخروج<input type="time" name="from" required></label>
      <label>وقت العودة<input type="time" name="to" required></label>
      <label>السبب<input name="reason" maxlength="80" required></label>
      <label>البديل<select name="subId" id="subSel"><option value="">— بدون بديل —</option>${subs.map(s => opt(s.id, s.name + ' — ' + ROLE[s.role])).join('')}</select></label>
      <label>بداية التغطية الفعلية<input type="time" name="covFrom"></label>
      <label>نهاية التغطية الفعلية<input type="time" name="covTo"></label>
      <div class="row gap wrap"><button type="button" class="btn" data-act="suggest">🔎 اقتراح بديل مناسب</button><button class="btn pri">حفظ</button></div></form>
    <div id="sugg">${sugg.length ? '<h4>البدائل المقترحة (حسب العبء والراحة)</h4>' + sugg.map(s => `<button class="btn sm ${s.ok ? '' : 'warnb'}" data-act="pickSub" data-id="${s.id}">${esc(s.name)} ${s.onShift ? '· في الشيفت' : '· خارج الشيفت'}${s.ok ? ' ✓' : ' ⚠ ' + esc(s.reasons.join('، '))}</button>`).join(' ') : ''}</div>
    <p class="muted">ترك بداية/نهاية التغطية فارغاً يعني أن البديل غطّى كامل مدة الخروج. يُحدَّث سجل العمل دون إعادة بناء الشيفت، ويُحتسب للبديل «ساعات تغطية إضافية».</p></div>
    <div class="card"><h3>سجل الخروج — ${shLabel(sh)}</h3>${(sh.exits || []).length ? exitTable(sh, true) : '<p class="muted">لا يوجد خروج مسجّل.</p>'}${alertHtml(alertsFor(sh, eng.analyze(sh)))}</div>`;
  }

  function vHand() {
    const ms = sorted().filter(s => s.month === ui.month);
    const nav = `<div class="row gap"><button class="btn sm" data-act="mprev">◀</button><b class="mt-title">${fmtMonth(ui.month)}</b><button class="btn sm" data-act="mnext">▶</button></div>`;
    if (!ms.length) return `<div class="card">${nav}<p class="muted mt">لا توجد شيفتات في هذا الشهر.</p></div>`;
    const hc = id => ms.filter(s => s.handover && s.handover.personId === id).length;
    return `<div class="card"><div class="row between wrap">${nav}<button class="btn no-print" data-act="print">🖨 طباعة / PDF</button></div>
    <div class="tscroll mt"><table data-export="handover"><thead><tr><th>#</th><th>البداية</th><th>النهاية</th><th>المسؤول</th><th>وقت التسليم</th><th>الاستلام</th><th>الملاحظات</th><th>معلّقات</th><th>التوقيع</th></tr></thead><tbody>${ms.map(sh => { const h = sh.handover || {}; return `<tr><td>${sh.no}</td><td>${sh.date} 14:00</td><td>${U.addDays(sh.date, 1)} 08:00</td><td>${esc(nm(h.personId))}</td><td>${esc((h.at || '').replace('T', ' '))}</td><td>${h.confirmed ? '✓ ' : ''}${esc(h.incoming ? nm(h.incoming) : '')}</td><td>${esc(h.notes)}</td><td>${esc(h.pending)}</td><td>${h.sign ? '✍ ' + esc(h.sign.name) + ' <small>' + esc(h.sign.hash.slice(0, 8)) + '</small>' : ''}</td></tr>`; }).join('')}</tbody></table></div></div>
    ${ms.map(sh => {
      const h = sh.handover || {}, people = eng.attAll(sh), all = db.staff.filter(s => s.active !== false);
      const cur = cyrb(JSON.stringify([sh.no, sh.date, h.personId, h.at, h.notes, h.pending, h.incoming])), signedOk = h.sign && h.sign.hash === cur;
      return `<details class="card no-print"><summary><b>شيفت #${sh.no}</b> — ${sh.date} · المسؤول: ${esc(nm(h.personId))} <small class="muted">(عدد مرات التسليم هذا الشهر: ${hc(h.personId)})</small> ${h.sign ? (signedOk ? '<span class="pill green">موقّع ✓</span>' : '<span class="pill amber">عُدّل بعد التوقيع</span>') : ''}</summary>
      <form data-form="handover" class="fgrid"><input type="hidden" name="id" value="${sh.id}">
        <label>المسؤول عن التسليم<select name="personId">${people.map(id => opt(id, nm(id), h.personId)).join('') || opt('', '—')}</select></label>
        <label>وقت التسليم<input type="datetime-local" name="at" value="${esc(h.at || '')}"></label>
        <label>المستلم (الطاقم القادم)<select name="incoming"><option value="">—</option>${all.map(s => opt(s.id, s.name, h.incoming)).join('')}</select></label>
        <label class="chk"><input type="checkbox" name="confirmed" ${h.confirmed ? 'checked' : ''}> تأكيد الاستلام من الطاقم</label>
        <label class="wide">ملاحظات<textarea name="notes" rows="2">${esc(h.notes)}</textarea></label>
        <label class="wide">مشكلات معلّقة<textarea name="pending" rows="2">${esc(h.pending)}</textarea></label>
        <label>الاسم للتوقيع الرقمي<input name="signName" value="${esc(h.sign ? h.sign.name : '')}" maxlength="40"></label>
        <div class="row gap wrap"><button class="btn pri" name="op" value="save">💾 حفظ</button><button class="btn" name="op" value="sign">✍ حفظ + توقيع رقمي</button></div>
        ${h.sign ? `<div class="muted wide">وُقّع بواسطة ${esc(h.sign.name)} في ${new Date(h.sign.t).toLocaleString('ar-EG-u-nu-latn')} — بصمة: ${esc(h.sign.hash)}</div>` : ''}</form></details>`;
    }).join('')}`;
  }

  function vRep() {
    const subs = [['month', 'شهري'], ['crit', 'الفترة الحرجة'], ['cmp', 'مقارنة العدالة'], ['shift', 'تقرير شيفت']];
    const nav = `<div class="card no-print"><div class="row between wrap"><div class="seg">${subs.map(s => `<button class="${ui.rep === s[0] ? 'on' : ''}" data-act="rep" data-r="${s[0]}">${s[1]}</button>`).join('')}</div>
      <div class="row gap wrap"><button class="btn sm" data-act="mprev">◀</button><b class="mt-title">${fmtMonth(ui.month)}</b><button class="btn sm" data-act="mnext">▶</button>
      <button class="btn" data-act="print">🖨 PDF / طباعة</button><button class="btn" data-act="xls">📗 Excel</button><button class="btn" data-act="csv">CSV</button></div></div></div>`;
    const R = eng.rows(ui.month);
    const spread = (r, k) => { const v = R.filter(x => x.role === r).map(x => x[k]); return v.length ? Math.max(...v) - Math.min(...v) : 0; };
    const head = `<div class="print-title">NurseShift — ${fmtMonth(ui.month)}</div>`;
    if (ui.rep === 'month') {
      return nav + head + `<div class="card"><h3>التقرير الشهري</h3><div class="tscroll"><table data-export="monthly"><thead><tr><th>الاسم</th><th>التخصص</th><th>شيفتات</th><th>ساعات العمل</th><th>تغطية إضافية</th><th>ساعات حرجة</th><th>فترات ليلية</th><th>أقل راحة (أيام)</th><th>التسليم</th><th>العبء</th></tr></thead><tbody>${R.map(r => `<tr><td>${esc(r.name)}</td><td>${ROLE[r.role]}</td><td>${r.shifts}</td><td>${h1(r.min)}</td><td>${h1(r.extra)}</td><td>${h1(r.crit)}</td><td>${(r.late / 120).toFixed(1)}</td><td>${r.minRest == null ? '—' : r.minRest}</td><td>${r.hand}</td><td>${r.burden.toFixed(1)}</td></tr>`).join('') || '<tr><td colspan="10">لا بيانات</td></tr>'}</tbody></table></div>
      <div class="gaps">${RK.map(r => `<span class="pill">فجوة ${ROLE_P[r]}: ساعات ${h1(spread(r, 'min'))} · حرجة ${h1(spread(r, 'crit'))}</span>`).join(' ')}</div></div>`;
    }
    if (ui.rep === 'crit') {
      const ms = sorted().filter(s => s.month === ui.month);
      const avg = r => { const v = R.filter(x => x.role === r); return v.length ? v.reduce((s, x) => s + x.crit, 0) / v.length : 0; };
      return nav + head + `<div class="card"><h3>ساعات الفترة الحرجة (2:00 ص – 7:00 ص) — بالدقيقة الدقيقة</h3><p class="muted">الساعة 6–8 ص تُحتسب ساعة حرجة واحدة (6–7 ص).</p><div class="tscroll"><table data-export="critical"><thead><tr><th>الاسم</th><th>التخصص</th><th>2–4 ص</th><th>4–6 ص</th><th>6–7 ص</th><th>المجموع</th><th>الانحراف عن المتوسط</th></tr></thead><tbody>${R.map(r => { const d = (r.crit - avg(r.role)) / 60; return `<tr><td>${esc(r.name)}</td><td>${ROLE[r.role]}</td><td>${h1(r.c1)}</td><td>${h1(r.c2)}</td><td>${h1(r.c3)}</td><td><b>${h1(r.crit)}</b></td><td class="${Math.abs(d) >= 2 ? 'neg' : ''}">${d > 0 ? '+' : ''}${d.toFixed(1)}</td></tr>`; }).join('') || '<tr><td colspan="7">لا بيانات</td></tr>'}</tbody></table></div></div>
      <div class="card"><h3>من كان في الفترة الحرجة في كل شيفت</h3><div class="tscroll"><table><thead><tr><th>#</th><th>التاريخ</th><th>2–4 ص (ممرض/تخدير)</th><th>4–6 ص</th><th>6–7 ص</th></tr></thead><tbody>${ms.map(s => `<tr><td>${s.no}</td><td>${s.date}</td>${[6, 7, 8].map(i => `<td>${esc(short(s.periods[i].nurse))} / ${esc(short(s.periods[i].assistant))}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>`;
    }
    if (ui.rep === 'cmp') {
      const A = eng.rows(null), mxA = Math.max(1, ...A.map(r => r.burden)), mxM = Math.max(1, ...R.map(r => r.burden));
      const block = (rowsX, mx, title) => RK.map(r => { const v = rowsX.filter(x => x.role === r), mean = v.length ? v.reduce((s, x) => s + x.burden, 0) / v.length : 0; return `<div class="card"><h3>${title} — ${ROLE_P[r]} <small class="muted">(متوسط العبء ${mean.toFixed(1)})</small></h3>${v.map(x => `<div class="cmp"><span>${esc(x.name)}</span><div class="bar"><i class="${x.burden > mean * 1.15 ? 'hi' : ''}" style="width:${Math.max(2, x.burden / mx * 100)}%"></i></div><b>${x.burden.toFixed(1)}</b><small class="${Math.abs(x.burden - mean) > mean * .15 ? 'neg' : 'muted'}">${x.burden - mean >= 0 ? '+' : ''}${(x.burden - mean).toFixed(1)}</small></div>`).join('') || '<p class="muted">لا بيانات</p>'}</div>`; }).join('');
      return nav + head + block(R, mxM, 'الشهر') + block(A, mxA, 'التراكمي');
    }
    const list = sorted();
    const sh = byId(ui.repShift) || byId(ui.shiftId) || (curShift().sh);
    if (!sh) return nav + empty('لا توجد شيفتات.');
    ui.repShift = sh.id;
    const a = eng.analyze(sh);
    return nav + `<div class="card no-print"><select data-chg="repShift">${list.map(s => opt(s.id, shLabel(s), sh.id)).join('')}</select></div>` + head + `<div class="card"><h3>تقرير الشيفت #${sh.no} — ${fmtDate(sh.date)}</h3>
      <div class="tscroll"><table data-export="shift"><thead><tr><th>الفترة</th><th>الوقت</th><th>الممرض</th><th>مساعد التخدير</th><th>الحالة</th></tr></thead><tbody>${sh.periods.map((p, i) => `<tr><td>${i + 1}</td><td>${pLabel(i)}</td><td>${esc(nm(p.nurse))}</td><td>${esc(nm(p.assistant))}</td><td>${STAT[a.ps[i]]}</td></tr>`).join('')}</tbody></table></div>
      <h4>الساعات الفعلية</h4><div class="tscroll"><table><thead><tr><th>الاسم</th><th>ساعات</th><th>إضافي</th><th>2–4</th><th>4–6</th><th>6–7</th></tr></thead><tbody>${Object.keys(a.per).map(id => { const m = a.per[id]; return `<tr><td>${esc(nm(id))}</td><td>${h1(m.min)}</td><td>${h1(m.extra)}</td><td>${h1(m.c1)}</td><td>${h1(m.c2)}</td><td>${h1(m.c3)}</td></tr>`; }).join('')}</tbody></table></div>
      ${(sh.exits || []).length ? '<h4>الخروج الطارئ</h4>' + exitTable(sh, false) : ''}
      <h4>التسليم والاستلام</h4><p>المسؤول: ${esc(nm(sh.handover && sh.handover.personId))} — ${esc((sh.handover && sh.handover.notes) || '')}</p>${alertHtml(alertsFor(sh, a))}</div>`;
  }

  function vSet() {
    const s = db.settings, w = s.w;
    const fn = (n, l, v, mn, mx, st) => `<label>${l}<input type="number" name="${n}" value="${v}" min="${mn}" max="${mx}" step="${st || 1}"></label>`;
    return `<div class="card"><h3>قواعد الشيفتات والتوزيع</h3><form data-form="settings" class="fgrid">
      ${fn('shiftsPerMonth', 'عدد الشيفتات شهرياً', s.shiftsPerMonth, 1, 28)}${fn('restDays', 'أيام الراحة بعد الشيفت', s.restDays, 0, 10)}
      ${fn('pn', 'عدد الممرضين في الشيفت (2–4)', s.perShift.nurse, 1, 4)}${fn('pa', 'عدد مساعدي التخدير في الشيفت (2–4)', s.perShift.assistant, 1, 4)}
      <label>نطاق احتساب العدالة<select name="scope">${opt('all', 'تراكمي (كل الأشهر)', s.scope)}${opt('month', 'الشهر الحالي فقط', s.scope)}</select></label>
      <h4 class="wide">أوزان العبء (كلما زاد الوزن زادت أهمية العامل)</h4>
      ${fn('w_hours', 'ساعات العمل', w.hours, 0, 20, 0.1)}${fn('w_extra', 'ساعات تغطية إضافية', w.extra, 0, 20, 0.1)}${fn('w_crit', 'الساعات الحرجة', w.crit, 0, 20, 0.1)}${fn('w_late', 'الفترات الليلية', w.late, 0, 20, 0.1)}${fn('w_shifts', 'عدد الشيفتات', w.shifts, 0, 20, 0.1)}${fn('w_rest', 'مكافأة الراحة (لكل يوم)', w.rest, 0, 20, 0.1)}
      <button class="btn pri">حفظ الإعدادات</button></form><p class="muted">الشيفت 18 ساعة (14:00–08:00) = 9 فترات × ساعتان. تغيير الإعدادات يسري على التوليد القادم.</p></div>
    <div class="card"><h3>🔐 الحماية</h3>${s.pin ? '<p>الرمز السري مفعّل (يُقفل التطبيق تلقائياً بعد 10 دقائق خمول).</p><button class="btn danger" data-act="rmPin">إزالة الرمز</button>' : '<form data-form="setPin" class="row gap wrap"><input name="pin" type="password" inputmode="numeric" minlength="4" required placeholder="رمز من 4 أرقام فأكثر"><button class="btn pri">تفعيل الرمز السري</button></form>'}</div>
    <div class="card"><h3>💾 النسخ الاحتياطي</h3><p class="muted">تُحفظ البيانات تلقائياً على الجهاز. خذ نسخة JSON دورية.</p><div class="row gap wrap"><button class="btn pri" data-act="backup">⬇ تصدير نسخة JSON</button><label class="btn">⬆ استعادة نسخة<input type="file" id="restoreFile" accept=".json,application/json" hidden></label><button class="btn danger" data-act="resetAll">🗑 مسح كل البيانات</button></div></div>
    <div class="card"><h3>🧾 سجل التدقيق (آخر 60)</h3><div class="tscroll"><table><thead><tr><th>الوقت</th><th>العملية</th><th>التفاصيل</th></tr></thead><tbody>${db.audit.slice(0, 60).map(x => `<tr><td>${new Date(x.t).toLocaleString('ar-EG-u-nu-latn')}</td><td>${esc(x.a)}</td><td>${esc(x.d)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">لا يوجد</td></tr>'}</tbody></table></div></div>`;
  }
  const VIEWS = { dash: vDash, sched: vSched, staff: vStaff, leave: vLeave, exit: vExit, hand: vHand, rep: vRep, set: vSet };

  // ---------- الأوامر ----------
  const hmm = id => { const sh = byId(id); return sh; };
  const keepAll = sh => eng.attAll(sh);
  const isPast = sh => Date.now() > startMs(sh) + 18 * 3600e3;
  const ACTS = {
    close: closeModal,
    tab(el) { ui.tab = el.dataset.tab; if (el.dataset.id) { ui.exShift = el.dataset.id; } render(); window.scrollTo(0, 0); },
    mprev() { ui.month = addMonth(ui.month, -1); render(); }, mnext() { ui.month = addMonth(ui.month, 1); render(); },
    rep(el) { ui.rep = el.dataset.r; render(); },
    lock() { ui.unlocked = false; render(); },
    print() { window.print(); },
    install() { if (deferred) { deferred.prompt(); deferred = null; render(); } },
    genMonth() {
      if (!db.staff.some(s => s.role === 'nurse' && s.active !== false) && !db.staff.some(s => s.role === 'assistant' && s.active !== false)) return toast('أضف الطاقم أولاً', 'bad');
      if (db.shifts.some(s => s.month === ui.month) && !confirm('سيتم استبدال جدول هذا الشهر بما فيه التسليم والخروج الطارئ. متابعة؟')) return;
      const made = eng.generateMonth(ui.month); log('توليد جدول', ui.month + ' (' + made.length + ' شيفتات)'); save(); ui.tab = 'sched'; render(); toast('تم توليد ' + made.length + ' شيفتات');
    },
    openShift(el) { ui.shiftId = el.dataset.id; ui.tab = 'dash'; render(); window.scrollTo(0, 0); },
    replanKeep(el) { const sh = byId(el.dataset.id); eng.generateShift(sh, { keep: keepAll(sh) }); log('إعادة توزيع', shLabel(sh)); save(); render(); toast('أُعيد التوزيع'); },
    replanFresh(el) { const sh = byId(el.dataset.id); if (!confirm('توزيع جديد يلغي التعديلات اليدوية. متابعة؟')) return; eng.generateShift(sh); log('توزيع جديد', shLabel(sh)); save(); render(); },
    delShift(el) { const sh = byId(el.dataset.id); if (!confirm('حذف الشيفت #' + sh.no + '؟')) return; db.shifts = db.shifts.filter(s => s !== sh); eng.renumber(sh.month); log('حذف شيفت', sh.date); save(); render(); },
    editDate(el) { const sh = byId(el.dataset.id); modal('تغيير تاريخ الشيفت #' + sh.no, `<form data-form="editDate"><input type="hidden" name="id" value="${sh.id}"><label>التاريخ (بداية الشيفت 14:00)<input type="date" name="date" value="${sh.date}" required></label><button class="btn pri block mt">حفظ وإعادة التوزيع</button></form>`); },
    ovr(el) {
      const sh = byId(el.dataset.id), i = +el.dataset.i, r = el.dataset.r;
      modal(`تعديل يدوي — الفترة ${i + 1} (${pLabel(i)})`, `<form data-form="ovr"><input type="hidden" name="id" value="${sh.id}"><input type="hidden" name="i" value="${i}"><input type="hidden" name="r" value="${r}"><label>${ROLE[r]}<select name="who"><option value="">— فارغ —</option>${db.staff.filter(s => s.role === r && s.active !== false).map(s => opt(s.id, s.name + (eng.onLeave(s.id, sh.date) ? ' (إجازة)' : ''), sh.periods[i][r])).join('')}</select></label><p class="muted">ستظهر تنبيهات التعارض (4 ساعات/الراحة/الإجازة) فوراً إن وُجدت.</p><button class="btn pri block">حفظ</button></form>`);
    },
    renameStaff(el) { const s = eng.staffById(el.dataset.id); modal('تعديل الاسم', `<form data-form="rename"><input type="hidden" name="id" value="${s.id}"><input name="name" value="${esc(s.name)}" required maxlength="40"><button class="btn pri block mt">حفظ</button></form>`); },
    delStaff(el) {
      const s = eng.staffById(el.dataset.id), used = db.shifts.some(x => eng.attAll(x).includes(s.id) || (x.exits || []).some(e => e.staffId === s.id || e.subId === s.id));
      if (!confirm((used ? 'سيتم أرشفة ' : 'سيتم حذف ') + s.name + '؟')) return;
      if (used) s.active = false; else { db.staff = db.staff.filter(x => x !== s); db.leaves = db.leaves.filter(l => l.staffId !== s.id); }
      log(used ? 'أرشفة موظف' : 'حذف موظف', s.name); save(); render();
    },
    restoreStaff(el) { const s = eng.staffById(el.dataset.id); s.active = true; log('استرجاع موظف', s.name); save(); render(); },
    delLeave(el) { db.leaves = db.leaves.filter(l => l.id !== el.dataset.id); log('حذف إجازة'); save(); render(); },
    delExit(el) { const sh = byId(el.dataset.id); sh.exits = sh.exits.filter(x => x.id !== el.dataset.x); log('حذف خروج طارئ', shLabel(sh)); save(); render(); },
    suggest() {
      const f = $('form[data-form="addExit"]'), fd = new FormData(f), sh = byId(fd.get('shiftId'));
      if (!fd.get('staffId') || !fd.get('from') || !fd.get('to')) return toast('اختر الموظف ووقتي الخروج والعودة أولاً', 'bad');
      const ex = { staffId: fd.get('staffId'), from: U.timeToOff(fd.get('from')), to: U.timeToOff(fd.get('to')) };
      if (ex.from >= 1080 || ex.to > 1080 || ex.to <= ex.from) return toast('وقت غير صالح — يجب أن يقع بين 14:00 و08:00 والعودة بعد الخروج', 'bad');
      ui.sugg = eng.suggestSubs(sh, ex).slice(0, 6);
      const keep = {}; fd.forEach((v, k) => { keep[k] = v; }); render();
      const nf = $('form[data-form="addExit"]'); Object.keys(keep).forEach(k => { const el = nf.elements[k]; if (el && el.type !== 'hidden') el.value = keep[k]; });
      if (!ui.sugg.length) toast('لا يوجد بديل مؤهل متاح', 'bad');
    },
    pickSub(el) { const s = $('#subSel'); if (s) s.value = el.dataset.id; },
    rmPin() { if (!confirm('إزالة الرمز السري؟')) return; db.settings.pin = null; log('إزالة الرمز السري'); save(); render(); },
    backup() { dl('nurseshift-backup-' + todayStr() + '.json', 'application/json', JSON.stringify(db, null, 2)); log('نسخة احتياطية'); save(); },
    resetAll() { if (!confirm('سيتم مسح كل البيانات نهائياً. هل أنت متأكد؟') || !confirm('تأكيد أخير: المسح لا يمكن التراجع عنه (يفضّل أخذ نسخة JSON أولاً).')) return; db = defaults(); save(); log('مسح كل البيانات'); save(); render(); },
    csv() { exportTable('csv'); }, xls() { exportTable('xls'); }
  };
  function exportTable(fmt) {
    const t = $('table[data-export]'); if (!t) return toast('لا يوجد جدول للتصدير في هذه الصفحة (جرّب التقرير الشهري)', 'bad');
    const rows = [...t.rows].map(r => [...r.cells].map(c => c.textContent.trim()));
    const name = 'nurseshift-' + t.dataset.export + '-' + ui.month;
    if (fmt === 'csv') dl(name + '.csv', 'text/csv;charset=utf-8', '﻿' + rows.map(r => r.map(c => '"' + c.replace(/"/g, '""') + '"').join(',')).join('\r\n'));
    else dl(name + '.xls', 'application/vnd.ms-excel;charset=utf-8', '<html dir="rtl"><head><meta charset="utf-8"></head><body><table border="1">' + rows.map((r, i) => '<tr>' + r.map(c => (i ? '<td>' : '<th>') + esc(c) + (i ? '</td>' : '</th>')).join('') + '</tr>').join('') + '</table></body></html>');
    log('تصدير', t.dataset.export + ' ' + fmt);
  }

  // ---------- النماذج ----------
  async function hashPin(pin, salt) {
    if (!(window.crypto && crypto.subtle)) return cyrb(salt + pin);
    const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
    const b = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: 120000, hash: 'SHA-256' }, k, 256);
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
  }
  const FORMS = {
    async unlock(f, d) { const p = db.settings.pin, h = await hashPin(String(d.get('pin')), p.salt); if (h === p.hash) { ui.unlocked = true; render(); } else { toast('الرمز غير صحيح', 'bad'); f.reset(); } },
    async setPin(f, d) { const salt = uid(), pin = String(d.get('pin')); db.settings.pin = { salt, hash: await hashPin(pin, salt) }; ui.unlocked = true; log('تفعيل الرمز السري'); save(); render(); toast('تم التفعيل'); },
    addStaff(f, d) { const name = String(d.get('name')).trim(); if (!name) return; db.staff.push({ id: uid(), name, role: d.get('role'), active: true }); log('إضافة موظف', name); save(); render(); },
    rename(f, d) { const s = eng.staffById(d.get('id')), old = s.name; s.name = String(d.get('name')).trim() || old; log('تعديل اسم', old + ' → ' + s.name); save(); closeModal(); render(); },
    editDate(f, d) {
      const sh = byId(d.get('id')), nd = d.get('date');
      if (db.shifts.some(s => s !== sh && s.date === nd)) return toast('يوجد شيفت آخر بنفس التاريخ', 'bad');
      const old = sh.month; sh.date = nd; sh.month = nd.slice(0, 7); eng.renumber(old); eng.renumber(sh.month);
      eng.generateShift(sh, { keep: keepAll(sh) }); log('تغيير تاريخ شيفت', nd); save(); closeModal(); render();
    },
    ovr(f, d) { const sh = byId(d.get('id')); sh.periods[+d.get('i')][d.get('r')] = d.get('who') || null; log('تعديل يدوي', shLabel(sh) + ' فترة ' + (+d.get('i') + 1) + ' → ' + (d.get('who') ? nm(d.get('who')) : 'فارغ')); save(); closeModal(); render(); },
    addLeave(f, d) {
      const l = { id: uid(), staffId: d.get('staffId'), from: d.get('from'), to: d.get('to'), note: String(d.get('note') || '') };
      if (l.to < l.from) return toast('تاريخ النهاية قبل البداية', 'bad');
      db.leaves.push(l); log('إجازة', nm(l.staffId) + ' ' + l.from + '→' + l.to);
      const hit = sorted().filter(sh => sh.date >= l.from && sh.date <= l.to && eng.attAll(sh).includes(l.staffId) && !isPast(sh));
      let probs = 0; hit.forEach(sh => { eng.generateShift(sh, { keep: keepAll(sh) }); const a = eng.analyze(sh); probs += a.unc.length + a.conflicts.length; log('إعادة توزيع تلقائية', shLabel(sh)); });
      save(); render();
      toast(hit.length ? `أُعيد توزيع ${hit.length} شيفت${probs ? ' — ⚠ تحقق من تحذيرات نقص الكادر' : ''}` : 'تم حفظ الإجازة', probs ? 'bad' : '');
    },
    addExit(f, d) {
      const sh = byId(d.get('shiftId')), from = U.timeToOff(d.get('from')), to = U.timeToOff(d.get('to'));
      if (from >= 1080 || to > 1080 || to <= from) return toast('وقت غير صالح — ضمن 14:00 إلى 08:00 والعودة بعد الخروج', 'bad');
      const x = { id: uid(), staffId: d.get('staffId'), from, to, reason: String(d.get('reason')), subId: d.get('subId') || null, covFrom: null, covTo: null };
      if (x.subId) { x.covFrom = d.get('covFrom') ? U.timeToOff(d.get('covFrom')) : from; x.covTo = d.get('covTo') ? U.timeToOff(d.get('covTo')) : to; if (x.covTo <= x.covFrom) return toast('نطاق التغطية غير صالح', 'bad'); }
      sh.exits = sh.exits || []; sh.exits.push(x); ui.sugg = [];
      log('خروج طارئ', nm(x.staffId) + ' ' + U.offTime(from) + '–' + U.offTime(to) + (x.subId ? ' بديل ' + nm(x.subId) : ' بلا بديل'));
      save(); render();
      const a = eng.analyze(sh); toast(a.unc.length || a.conflicts.length ? 'تم التسجيل — يوجد تنبيه تغطية/تعارض' : 'تم التسجيل وتحديث سجل العمل', a.unc.length || a.conflicts.length ? 'bad' : '');
    },
    handover(f, d, ev) {
      const sh = byId(d.get('id')), h = sh.handover || (sh.handover = {});
      Object.assign(h, { personId: d.get('personId') || null, at: d.get('at') || '', incoming: d.get('incoming') || '', confirmed: d.get('confirmed') === 'on', notes: String(d.get('notes') || ''), pending: String(d.get('pending') || '') });
      if (ev && ev.submitter && ev.submitter.value === 'sign') {
        const name = String(d.get('signName') || '').trim(); if (!name) return toast('أدخل الاسم للتوقيع', 'bad');
        if (!h.at) h.at = new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
        h.sign = { name, t: Date.now(), hash: cyrb(JSON.stringify([sh.no, sh.date, h.personId, h.at, h.notes, h.pending, h.incoming])) }; log('توقيع تسليم', shLabel(sh) + ' — ' + name);
      } else log('تحديث تسليم', shLabel(sh));
      save(); render(); toast('تم الحفظ');
    },
    settings(f, d) {
      const n = (k, mn, mx) => Math.max(mn, Math.min(mx, parseFloat(d.get(k)) || 0)), s = db.settings;
      s.shiftsPerMonth = n('shiftsPerMonth', 1, 28); s.restDays = n('restDays', 0, 10); s.perShift = { nurse: n('pn', 1, 4), assistant: n('pa', 1, 4) }; s.scope = d.get('scope');
      ['hours', 'extra', 'crit', 'late', 'shifts', 'rest'].forEach(k => { s.w[k] = n('w_' + k, 0, 20); });
      log('تعديل الإعدادات'); save(); render(); toast('تم الحفظ');
    }
  };
  const CHG = {
    dashShift(el) { ui.shiftId = el.value; render(); }, exShift(el) { ui.exShift = el.value; ui.sugg = []; render(); }, repShift(el) { ui.repShift = el.value; render(); }
  };

  // ---------- الأحداث ----------
  document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (!el) return; if (el.tagName === 'A') e.preventDefault(); const fn = ACTS[el.dataset.act]; if (fn) fn(el, e); });
  document.addEventListener('submit', e => { const f = e.target.closest('form[data-form]'); if (!f) return; e.preventDefault(); FORMS[f.dataset.form](f, new FormData(f), e); });
  document.addEventListener('change', e => {
    const el = e.target.closest('[data-chg]'); if (el) return CHG[el.dataset.chg](el);
    if (e.target.id === 'restoreFile') {
      const file = e.target.files[0]; if (!file) return;
      const rd = new FileReader();
      rd.onload = () => { try { const d = JSON.parse(rd.result); if (!Array.isArray(d.staff) || !Array.isArray(d.shifts)) throw new Error('ملف غير صالح'); if (!confirm('ستُستبدل كل البيانات الحالية بالنسخة. متابعة؟')) return; db = normalize(d); log('استعادة نسخة احتياطية', file.name); save(); ui.unlocked = !db.settings.pin; render(); toast('تمت الاستعادة'); } catch (err) { toast('فشلت الاستعادة: ' + err.message, 'bad'); } };
      rd.readAsText(file);
    }
  });
  let idle; const bump = () => { clearTimeout(idle); if (db.settings.pin && ui.unlocked) idle = setTimeout(() => { ui.unlocked = false; render(); }, 600000); };
  ['click', 'keydown', 'touchstart'].forEach(ev => document.addEventListener(ev, bump, { passive: true }));
  let deferred = null;
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; render(); });
  window.addEventListener('beforeprint', () => { document.title = 'NurseShift'; });

  if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => { }));
  render();
})();
