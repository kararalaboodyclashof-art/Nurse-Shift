# NurseShift — تحويل التطبيق إلى APK (مجاناً)

الملفات: index.html · style.css · engine.js · app.js · sw.js · manifest.json · icon-192.png · icon-512.png · icon-maskable-512.png
(ارفعها كلها في نفس المجلد دون تغيير الأسماء)

## 1) الاستضافة المجانية (HTTPS مطلوب)
أسهل خيار: https://app.netlify.com/drop  → اسحب مجلد الملفات → تحصل على رابط https فوراً.
بدائل: GitHub Pages · Cloudflare Pages · Vercel · Firebase Hosting.

## 2) تثبيت فوري على الهاتف (بدون APK)
افتح الرابط في Chrome على أندرويد → ⋮ → «تثبيت التطبيق» / «إضافة إلى الشاشة الرئيسية». يعمل بدون إنترنت.

## 3) بناء APK
أ) https://www.pwabuilder.com  → الصق رابط موقعك → Package for stores → Android → Generate → حمّل ملف APK (أو AAB للمتجر).
   لتثبيت APK مباشرة: فعّل «التثبيت من مصادر غير معروفة» في الهاتف.
ب) بدائل: Bubblewrap CLI (من Google) أو Capacitor + Android Studio.

## ملاحظات
- البيانات تُحفظ تلقائياً على الجهاز؛ خذ نسخة JSON من الإعدادات بشكل دوري.
- تصدير PDF: زر «طباعة / PDF» ثم «حفظ كـ PDF» (يدعم العربية).
